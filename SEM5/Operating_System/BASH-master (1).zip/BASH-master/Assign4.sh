#! /bin/bash

echo "Current Directory:`pwd`"
echo "The total number of files in current directory and all its subdirectories are : `find . -type f | wc -l`"

