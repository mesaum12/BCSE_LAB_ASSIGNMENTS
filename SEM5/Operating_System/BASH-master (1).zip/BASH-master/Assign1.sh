#! /bin/bash

you=Hello!
echo "$you"
echo "\"$you\""
echo "'$you'"

