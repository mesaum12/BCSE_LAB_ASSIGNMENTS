#! /bin/bash

echo "Enter value of variable uv1 "
read uv1 
echo "Enter value of variable uv2"
read uv2
echo -n "Separated by a Comma:"
echo "$uv1,$uv2"
echo -n "Separated by the word and:"
echo "$uv1""and""$uv2"
