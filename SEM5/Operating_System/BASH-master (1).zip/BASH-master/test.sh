read file
n="${file%.*}0.txt"
echo $n